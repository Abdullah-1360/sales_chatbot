/**
 * ConfigServer Security & Firewall (CSF) API Service
 * Provides CSF firewall management functionality
 */

const axios = require('axios');
const https = require('https');

class CSFService {
  constructor() {
    this.username = process.env.WHM_USERNAME || 'root';
    this.verifySSL = process.env.WHM_VERIFY_SSL !== 'false';
    
    // Load server API keys from WHM service
    this.serverApiKeys = this.loadServerApiKeys();
    
    // CSF API endpoints
    this.csfEndpoints = {
      grepip: '/cgi/configserver/csf.cgi',
      allow: '/cgi/configserver/csf.cgi',
      deny: '/cgi/configserver/csf.cgi'
    };
    
    if (process.env.NODE_ENV !== 'production') {
      console.log('🔧 CSF Service initialized:', {
        username: this.username,
        serversConfigured: Object.keys(this.serverApiKeys).length,
        sslVerify: this.verifySSL
      });
    }
  }

  /**
   * Load server-specific API keys from environment variables
   * @returns {Object} Map of server names to API keys
   */
  loadServerApiKeys() {
    const apiKeys = {};
    
    // Load all WHM_API_KEY_* environment variables
    Object.keys(process.env).forEach(key => {
      if (key.startsWith('WHM_API_KEY_')) {
        const serverName = key.replace('WHM_API_KEY_', '').toLowerCase();
        apiKeys[serverName] = process.env[key];
      }
    });
    
    return apiKeys;
  }

  /**
   * Get server hostname from server name
   * @param {string} serverName - Server name (e.g., 'cp1', 'pcp6')
   * @returns {string} Server hostname
   */
  getServerHostname(serverName) {
    const name = serverName.toLowerCase();
    
    // Map server names to hostnames based on your naming convention
    if (name.startsWith('cp') && !name.startsWith('pcp')) {
      return `${name}.mywebsitebox.com`;
    } else if (name.startsWith('pcp')) {
      return `${name}.mywebsitebox.com`;
    } else if (name.startsWith('rcp')) {
      return `${name}.mywebsitebox.com`;
    } else if (name.includes('plesk') || name.includes('win')) {
      return 'plesk.hostbreak.com'; // Windows servers
    }
    
    // Default fallback
    return `${name}.mywebsitebox.com`;
  }

  /**
   * Create axios client for CSF API calls
   * @param {string} serverName - Server name
   * @returns {Object} Configured axios client
   */
  createCSFClient(serverName) {
    const hostname = this.getServerHostname(serverName);
    const baseURL = `https://${hostname}:2087`;
    const apiKey = this.serverApiKeys[serverName.toLowerCase()];
    
    if (!apiKey) {
      throw new Error(`No API key found for server: ${serverName}`);
    }
    
    const client = axios.create({
      baseURL: baseURL,
      timeout: 15000,
      httpsAgent: new https.Agent({
        rejectUnauthorized: this.verifySSL
      }),
      headers: {
        'Authorization': `whm ${this.username}:${apiKey}`,
        'User-Agent': 'cPHulk-Manager/1.0'
      }
    });
    
    return client;
  }

  /**
   * Check if IP exists in CSF firewall rules (allow/deny lists)
   * @param {string} ip - IP address to check
   * @param {string} serverName - Server name (optional, will use default if not provided)
   * @returns {Promise<Object>} CSF grep result
   */
  async grepIP(ip, serverName = 'pcp3') {
    try {
      const client = this.createCSFClient(serverName);
      
      console.log(`→ Checking IP ${ip} in CSF firewall rules on server ${serverName}`);
      
      const response = await client.get(this.csfEndpoints.grepip, {
        params: {
          action: 'grepip',
          ip: ip
        }
      });

      // Parse CSF response
      const result = this.parseCSFResponse(response.data, ip);
      
      console.log(`→ CSF grep result for IP ${ip}:`, {
        found: result.found,
        rules: result.rules.length,
        inAllowList: result.inAllowList,
        inDenyList: result.inDenyList
      });

      return {
        success: true,
        ip: ip,
        serverName: serverName,
        found: result.found,
        rules: result.rules,
        inAllowList: result.inAllowList,
        inDenyList: result.inDenyList,
        summary: result.summary,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      console.error(`Error checking IP ${ip} in CSF:`, error.message);
      
      return {
        success: false,
        ip: ip,
        serverName: serverName,
        error: error.message,
        found: false,
        rules: [],
        inAllowList: false,
        inDenyList: false,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Parse CSF API response
   * @param {string} responseData - Raw CSF response
   * @param {string} ip - IP address that was searched
   * @returns {Object} Parsed result
   */
  parseCSFResponse(responseData, ip) {
    const result = {
      found: false,
      rules: [],
      inAllowList: false,
      inDenyList: false,
      summary: 'IP not found in any CSF rules'
    };

    try {
      // CSF responses can be HTML or plain text
      const responseText = responseData.toString();
      
      // Check if response contains IP matches
      if (responseText.includes(ip)) {
        result.found = true;
        
        // Parse different types of CSF rules
        const lines = responseText.split('\n');
        
        for (const line of lines) {
          const trimmedLine = line.trim();
          
          if (trimmedLine.includes(ip)) {
            // Determine rule type based on content
            let ruleType = 'unknown';
            let ruleFile = 'unknown';
            
            if (trimmedLine.includes('csf.allow') || trimmedLine.includes('allow')) {
              ruleType = 'allow';
              ruleFile = 'csf.allow';
              result.inAllowList = true;
            } else if (trimmedLine.includes('csf.deny') || trimmedLine.includes('deny')) {
              ruleType = 'deny';
              ruleFile = 'csf.deny';
              result.inDenyList = true;
            } else if (trimmedLine.includes('csf.ignore')) {
              ruleType = 'ignore';
              ruleFile = 'csf.ignore';
            }
            
            result.rules.push({
              type: ruleType,
              file: ruleFile,
              line: trimmedLine,
              ip: ip
            });
          }
        }
        
        // Generate summary
        if (result.inAllowList && result.inDenyList) {
          result.summary = `IP ${ip} found in both allow and deny lists`;
        } else if (result.inAllowList) {
          result.summary = `IP ${ip} is in CSF allow list`;
        } else if (result.inDenyList) {
          result.summary = `IP ${ip} is in CSF deny list`;
        } else {
          result.summary = `IP ${ip} found in CSF rules but not in allow/deny lists`;
        }
      }
      
    } catch (parseError) {
      console.error('Error parsing CSF response:', parseError.message);
      result.summary = 'Error parsing CSF response';
    }

    return result;
  }

  /**
   * Add IP to CSF allow list
   * @param {string} ip - IP address to allow
   * @param {string} serverName - Server name
   * @param {string} comment - Optional comment for the rule
   * @returns {Promise<Object>} CSF allow result
   */
  async allowIP(ip, serverName = 'pcp3', comment = 'Added via API') {
    try {
      const client = this.createCSFClient(serverName);
      
      console.log(`→ Adding IP ${ip} to CSF allow list on server ${serverName}`);
      
      const response = await client.post(this.csfEndpoints.allow, null, {
        params: {
          action: 'allow',
          ip: ip,
          comment: comment
        }
      });

      return {
        success: true,
        ip: ip,
        serverName: serverName,
        action: 'allow',
        comment: comment,
        message: `IP ${ip} added to CSF allow list`,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      console.error(`Error adding IP ${ip} to CSF allow list:`, error.message);
      
      return {
        success: false,
        ip: ip,
        serverName: serverName,
        action: 'allow',
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Remove IP from CSF deny list
   * @param {string} ip - IP address to remove from deny list
   * @param {string} serverName - Server name
   * @returns {Promise<Object>} CSF unblock result
   */
  async unblockIP(ip, serverName = 'pcp3') {
    try {
      const client = this.createCSFClient(serverName);
      
      console.log(`→ Removing IP ${ip} from CSF deny list on server ${serverName}`);
      
      const response = await client.post(this.csfEndpoints.deny, null, {
        params: {
          action: 'unblock',
          ip: ip
        }
      });

      return {
        success: true,
        ip: ip,
        serverName: serverName,
        action: 'unblock',
        message: `IP ${ip} removed from CSF deny list`,
        timestamp: new Date().toISOString()
      };

    } catch (error) {
      console.error(`Error removing IP ${ip} from CSF deny list:`, error.message);
      
      return {
        success: false,
        ip: ip,
        serverName: serverName,
        action: 'unblock',
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Comprehensive IP analysis combining CSF rules and cPHulk status
   * @param {string} ip - IP address to analyze
   * @param {string} serverName - Server name
   * @returns {Promise<Object>} Comprehensive analysis result
   */
  async analyzeIP(ip, serverName = 'pcp3') {
    try {
      console.log(`→ Starting comprehensive IP analysis for ${ip} on server ${serverName}`);
      
      // Check CSF firewall rules
      const csfResult = await this.grepIP(ip, serverName);
      
      const analysis = {
        success: true,
        ip: ip,
        serverName: serverName,
        csf: csfResult,
        recommendations: [],
        riskLevel: 'low',
        timestamp: new Date().toISOString()
      };

      // Generate recommendations based on CSF status
      if (csfResult.inDenyList) {
        analysis.riskLevel = 'high';
        analysis.recommendations.push({
          type: 'warning',
          message: 'IP is currently blocked by CSF firewall',
          action: 'Consider unblocking IP before whitelisting in cPHulk'
        });
      }

      if (csfResult.inAllowList) {
        analysis.recommendations.push({
          type: 'info',
          message: 'IP is already in CSF allow list',
          action: 'CSF firewall will not block this IP'
        });
      }

      if (!csfResult.found) {
        analysis.recommendations.push({
          type: 'info',
          message: 'IP not found in CSF rules',
          action: 'Consider adding to CSF allow list for additional protection'
        });
      }

      return analysis;

    } catch (error) {
      console.error(`Error analyzing IP ${ip}:`, error.message);
      
      return {
        success: false,
        ip: ip,
        serverName: serverName,
        error: error.message,
        riskLevel: 'unknown',
        timestamp: new Date().toISOString()
      };
    }
  }
}

module.exports = CSFService;